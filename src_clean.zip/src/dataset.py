import torch
from torch.utils.data import Dataset
import numpy as np
import pandas as pd
import librosa

class MergeAudioDataset(Dataset):
    def __init__(self, tracks_csv):
        self.df = pd.read_csv(tracks_csv)
        self.q_map = {"Q1":0, "Q2":1, "Q3":2, "Q4":3}

    def __len__(self):
        return len(self.df)

    def __getitem__(self, idx):
        row = self.df.iloc[idx]

        y, sr = librosa.load(row.audio_path, sr=22050, mono=True)
        mel = librosa.feature.melspectrogram(
            y=y, sr=sr, n_mels=128, n_fft=2048, hop_length=512
        )
        mel = librosa.power_to_db(mel, ref=np.max)

        # Fix size (time axis)
        mel = mel[:, :128]
        if mel.shape[1] < 128:
            mel = np.pad(mel, ((0,0),(0,128-mel.shape[1])), mode="constant")

        # Normalize to [0,1]
        mel = (mel - mel.min()) / (mel.max() - mel.min() + 1e-8)

        mel = torch.tensor(mel).unsqueeze(0).float()  # (1,128,128)

        q = self.q_map[str(row.quadrant).strip()]
        q = torch.tensor(q).long()

        return mel, q
