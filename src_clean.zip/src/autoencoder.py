import torch
import torch.nn as nn

class CNN_Autoencoder(nn.Module):
    def __init__(self, latent_dim=32):
        super().__init__()

        # Encoder
        self.enc = nn.Sequential(
            nn.Conv2d(1, 32, 4, 2, 1),
            nn.ReLU(),
            nn.Conv2d(32, 64, 4, 2, 1),
            nn.ReLU(),
            nn.Conv2d(64, 128, 4, 2, 1),
            nn.ReLU(),
            nn.Flatten()
        )

        self.fc_latent = nn.Linear(128*16*16, latent_dim)

        # Decoder
        self.fc_dec = nn.Linear(latent_dim, 128*16*16)
        self.dec = nn.Sequential(
            nn.ConvTranspose2d(128, 64, 4, 2, 1),
            nn.ReLU(),
            nn.ConvTranspose2d(64, 32, 4, 2, 1),
            nn.ReLU(),
            nn.ConvTranspose2d(32, 1, 4, 2, 1),
            nn.Sigmoid()
        )

    def forward(self, x):
        h = self.enc(x)
        z = self.fc_latent(h)
        h_dec = self.fc_dec(z).view(-1, 128, 16, 16)
        x_hat = self.dec(h_dec)
        return x_hat, z
