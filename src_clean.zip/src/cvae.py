import torch
import torch.nn as nn
import torch.nn.functional as F

class CNN_CVAE(nn.Module):
    def __init__(self, latent_dim=32):
        super().__init__()

        self.q_embed = nn.Embedding(4, 8)

        # Encoder
        self.enc = nn.Sequential(
            nn.Conv2d(1, 32, 4, 2, 1),   # 64x64
            nn.ReLU(),
            nn.Conv2d(32, 64, 4, 2, 1),  # 32x32
            nn.ReLU(),
            nn.Conv2d(64, 128, 4, 2, 1), # 16x16
            nn.ReLU(),
            nn.Flatten()
        )

        self.fc_mu = nn.Linear(128*16*16 + 8, latent_dim)
        self.fc_logvar = nn.Linear(128*16*16 + 8, latent_dim)

        # Decoder
        self.fc_dec = nn.Linear(latent_dim + 8, 128*16*16)

        self.dec = nn.Sequential(
            nn.ConvTranspose2d(128, 64, 4, 2, 1),
            nn.ReLU(),
            nn.ConvTranspose2d(64, 32, 4, 2, 1),
            nn.ReLU(),
            nn.ConvTranspose2d(32, 1, 4, 2, 1),
            nn.Sigmoid()
        )

    def reparam(self, mu, logvar):
        std = torch.exp(0.5 * logvar)
        eps = torch.randn_like(std)
        return mu + eps * std

    def forward(self, x, q):
        q_emb = self.q_embed(q)

        h = self.enc(x)
        hq = torch.cat([h, q_emb], dim=1)

        mu = self.fc_mu(hq)
        logvar = self.fc_logvar(hq)
        z = self.reparam(mu, logvar)

        zq = torch.cat([z, q_emb], dim=1)
        h_dec = self.fc_dec(zq).view(-1, 128, 16, 16)
        x_hat = self.dec(h_dec)

        return x_hat, mu, logvar, z
